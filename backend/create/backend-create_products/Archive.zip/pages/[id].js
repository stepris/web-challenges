import Product from "../components/Product";

export default function ProductDetailsPage() {
  return <Product />;
}
